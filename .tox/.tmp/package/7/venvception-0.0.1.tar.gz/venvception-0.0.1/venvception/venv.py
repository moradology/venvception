import contextlib
import hashlib
import os
import subprocess
import sys
import tempfile

from pathlib import Path
from venv import EnvBuilder

@contextlib.contextmanager
def venv(requirements_file: Path, env_name: str = None):
    if not requirements_file.exists():
        raise FileNotFoundError(f"{requirements_file} does not exist.")

    id = env_name or hash_file_id(requirements_file)
    with tempfile.TemporaryDirectory(prefix=env_name) as tempdir:
        env_dir = os.path.join(tempdir, env_name)
        
        builder = EnvBuilder(with_pip=True)
        builder.create(env_dir)

        pip_install(env_dir, requirements_file)

        original_sys_path = list(sys.path)
        activate_virtualenv(env_dir)

        try:
            yield
        finally:
            sys.path[:] = original_sys_path

def hash_file_id(filepath: Path):
    hash_sha256 = hashlib.sha256()

    with open(filepath, 'rb') as f:
        while chunk := f.read(8192):
            hash_sha256.update(chunk)

    return hash_sha256.hexdigest()

def get_pip_path(env_dir):
    if sys.platform == "win32":
        return os.path.join(env_dir, 'Scripts', 'pip.exe')
    else:
        return os.path.join(env_dir, 'bin', 'pip')

def pip_install(env_dir: Path, requirements_file: Path) -> None:
    pip_executable = get_pip_path(env_dir)
    subprocess.check_call([pip_executable, 'install', '-r', requirements_file])

def activate_virtualenv(env_dir: Path) -> None:
    site_packages_path = os.path.join(env_dir, 'lib', f'python{sys.version_info.major}.{sys.version_info.minor}', 'site-packages')
    sys.path.insert(0, site_packages_path)
