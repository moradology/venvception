from pathlib import Path

from venvception import venv

with venv(Path("./requirements.txt")):
    import stac_pydantic
