from pathlib import Path

from venvception import venv

with venv(Path("tests/requirements.txt")):
    import stac_pydantic
